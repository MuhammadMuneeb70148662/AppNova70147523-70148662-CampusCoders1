package com.campusfind.app.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** One lost or found report. */
public class Item {
    public static final String TYPE_LOST = "Lost";
    public static final String TYPE_FOUND = "Found";
    public static final String STATUS_OPEN = "Open";
    public static final String STATUS_RETURNED = "Returned";

    private static final DateTimeFormatter DISPLAY_FORMAT =
            DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

    private int number;          // 7 for CF-07
    private String code;         // "CF-07"
    private String type;
    private String title;
    private String category;
    private String place;
    private String dateIso;      // yyyy-MM-dd, so it sorts correctly in SQL
    private double latitude;
    private double longitude;
    private String reportedBy;
    private String reporterEmail;
    private String contact;
    private String status;

    // only filled in by the Nearby tab, never stored
    private float distanceMeters = -1f;

    public int getNumber() { return number; }
    public void setNumber(int number) { this.number = number; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getPlace() { return place; }
    public void setPlace(String place) { this.place = place; }
    public String getDateIso() { return dateIso; }
    public void setDateIso(String dateIso) { this.dateIso = dateIso; }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public String getReportedBy() { return reportedBy; }
    public void setReportedBy(String reportedBy) { this.reportedBy = reportedBy; }
    public String getReporterEmail() { return reporterEmail; }
    public void setReporterEmail(String reporterEmail) { this.reporterEmail = reporterEmail; }
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public float getDistanceMeters() { return distanceMeters; }
    public void setDistanceMeters(float distanceMeters) { this.distanceMeters = distanceMeters; }

    public boolean isLost() { return TYPE_LOST.equals(type); }
    public boolean isReturned() { return STATUS_RETURNED.equals(status); }

    /** e.g. 12-Nov-2026 */
    public String getDisplayDate() {
        try {
            return LocalDate.parse(dateIso).format(DISPLAY_FORMAT);
        } catch (Exception e) {
            return dateIso;
        }
    }
}
