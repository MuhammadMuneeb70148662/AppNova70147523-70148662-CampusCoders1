package com.campusfind.app.ui;

import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.campusfind.app.R;
import com.campusfind.app.model.Item;
import com.campusfind.app.util.DistanceFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Shows items as cards. Used by both Home and Nearby. */
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.Holder> {

    public interface OnItemClickListener {
        void onItemClick(Item item);
    }

    private final List<Item> items = new ArrayList<>();
    private final OnItemClickListener listener;

    public ItemAdapter(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setItems(List<Item> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_card, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Item item = items.get(position);
        int tagColor = ContextCompat.getColor(h.itemView.getContext(),
                item.isLost() ? R.color.tag_lost : R.color.tag_found);

        h.tvType.setText(item.getType().toUpperCase(Locale.ROOT));
        h.tvType.setBackgroundTintList(ColorStateList.valueOf(tagColor));
        h.vStrip.setBackgroundColor(tagColor);

        h.tvReturned.setVisibility(item.isReturned() ? View.VISIBLE : View.GONE);
        h.tvReturned.setBackgroundTintList(ColorStateList.valueOf(
                ContextCompat.getColor(h.itemView.getContext(), R.color.tag_returned)));

        h.tvCode.setText(item.getCode());
        h.tvTitle.setText(item.getTitle());
        h.tvMeta.setText(item.getCategory() + "  •  " + item.getPlace());
        h.tvDate.setText(item.getDisplayDate());

        if (item.getDistanceMeters() >= 0) {
            h.tvDistance.setVisibility(View.VISIBLE);
            h.tvDistance.setText(DistanceFormatter.format(item.getDistanceMeters()) + " away");
        } else {
            h.tvDistance.setVisibility(View.GONE);
        }

        h.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final View vStrip;
        final TextView tvType, tvReturned, tvCode, tvTitle, tvMeta, tvDate, tvDistance;

        Holder(@NonNull View v) {
            super(v);
            vStrip = v.findViewById(R.id.v_strip);
            tvType = v.findViewById(R.id.tv_type_tag);
            tvReturned = v.findViewById(R.id.tv_returned_tag);
            tvCode = v.findViewById(R.id.tv_code);
            tvTitle = v.findViewById(R.id.tv_title);
            tvMeta = v.findViewById(R.id.tv_meta);
            tvDate = v.findViewById(R.id.tv_date);
            tvDistance = v.findViewById(R.id.tv_distance);
        }
    }
}
