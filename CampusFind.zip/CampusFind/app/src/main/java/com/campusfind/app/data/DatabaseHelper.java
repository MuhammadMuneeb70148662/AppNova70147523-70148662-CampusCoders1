package com.campusfind.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.campusfind.app.model.Item;
import com.campusfind.app.model.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Local SQLite storage for accounts and items.
 * The six starter items are inserted the first time the database is created (R9 / F4).
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "campusfind.db";
    private static final int DB_VERSION = 1;

    private static final String SEED_REPORTER = "Student Affairs";
    private static final String SEED_CONTACT = "03001234567";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "full_name TEXT NOT NULL,"
                + "email TEXT NOT NULL UNIQUE,"
                + "salt TEXT NOT NULL,"
                + "password_hash TEXT NOT NULL)");

        db.execSQL("CREATE TABLE items ("
                + "id_num INTEGER PRIMARY KEY,"
                + "code TEXT NOT NULL,"
                + "type TEXT NOT NULL,"
                + "title TEXT NOT NULL,"
                + "category TEXT NOT NULL,"
                + "place TEXT NOT NULL,"
                + "date_iso TEXT NOT NULL,"
                + "latitude REAL NOT NULL,"
                + "longitude REAL NOT NULL,"
                + "reported_by TEXT NOT NULL,"
                + "reporter_email TEXT NOT NULL,"
                + "contact TEXT NOT NULL,"
                + "status TEXT NOT NULL)");

        seedStarterItems(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS items");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    private void seedStarterItems(SQLiteDatabase db) {
        seed(db, 1, "Found", "Black leather wallet", "Wallets & Cards", "Main Library", "2026-11-12", 31.38955, 74.24070);
        seed(db, 2, "Lost", "Casio fx-991ES calculator", "Electronics", "CS Block", "2026-11-11", 31.38990, 74.24120);
        seed(db, 3, "Found", "Student ID card", "Wallets & Cards", "Cafeteria", "2026-11-10", 31.38880, 74.24010);
        seed(db, 4, "Lost", "Blue water bottle", "Other", "Sports Ground", "2026-11-09", 31.38800, 74.24200);
        seed(db, 5, "Found", "Car keys, red keychain", "Keys", "Main Parking", "2026-11-08", 31.39050, 74.23950);
        seed(db, 6, "Lost", "32 GB USB flash drive", "Electronics", "Mosque", "2026-11-07", 31.38920, 74.24180);
    }

    private void seed(SQLiteDatabase db, int number, String type, String title, String category,
                      String place, String dateIso, double lat, double lng) {
        ContentValues v = new ContentValues();
        v.put("id_num", number);
        v.put("code", formatCode(number));
        v.put("type", type);
        v.put("title", title);
        v.put("category", category);
        v.put("place", place);
        v.put("date_iso", dateIso);
        v.put("latitude", lat);
        v.put("longitude", lng);
        v.put("reported_by", SEED_REPORTER);
        v.put("reporter_email", "");
        v.put("contact", SEED_CONTACT);
        v.put("status", Item.STATUS_OPEN);
        db.insert("items", null, v);
    }

    private static String formatCode(int number) {
        return String.format(Locale.US, "CF-%02d", number);
    }

    // ---------------------------------------------------------------- users

    /** @return false when the email is already registered */
    public boolean addUser(User user) {
        ContentValues v = new ContentValues();
        v.put("full_name", user.getFullName());
        v.put("email", user.getEmail().toLowerCase(Locale.ROOT));
        v.put("salt", user.getSalt());
        v.put("password_hash", user.getPasswordHash());
        try {
            return getWritableDatabase().insertOrThrow("users", null, v) != -1;
        } catch (SQLiteConstraintException duplicate) {
            return false;
        }
    }

    public User findUser(String email) {
        Cursor c = getReadableDatabase().query("users", null, "email = ?",
                new String[]{email.toLowerCase(Locale.ROOT)}, null, null, null);
        try {
            if (c.moveToFirst()) {
                return new User(
                        c.getString(c.getColumnIndexOrThrow("full_name")),
                        c.getString(c.getColumnIndexOrThrow("email")),
                        c.getString(c.getColumnIndexOrThrow("salt")),
                        c.getString(c.getColumnIndexOrThrow("password_hash")));
            }
            return null;
        } finally {
            c.close();
        }
    }

    // ---------------------------------------------------------------- items

    /** Newest date first; for the same date the higher ID first (R6). */
    public List<Item> getAllItems() {
        List<Item> list = new ArrayList<>();
        Cursor c = getReadableDatabase().query("items", null, null, null, null, null,
                "date_iso DESC, id_num DESC");
        try {
            while (c.moveToNext()) {
                list.add(readItem(c));
            }
        } finally {
            c.close();
        }
        return list;
    }

    public Item getItem(String code) {
        Cursor c = getReadableDatabase().query("items", null, "code = ?",
                new String[]{code}, null, null, null);
        try {
            return c.moveToFirst() ? readItem(c) : null;
        } finally {
            c.close();
        }
    }

    /**
     * Saves a new item. The next ID (CF-07, CF-08, ...) is worked out inside the same
     * transaction so two quick saves can never get the same number (R5).
     *
     * @return the generated code, e.g. "CF-07"
     */
    public String insertItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            int next = 1;
            Cursor c = db.rawQuery("SELECT COALESCE(MAX(id_num), 0) FROM items", null);
            if (c.moveToFirst()) {
                next = c.getInt(0) + 1;
            }
            c.close();

            String code = formatCode(next);
            ContentValues v = new ContentValues();
            v.put("id_num", next);
            v.put("code", code);
            v.put("type", item.getType());
            v.put("title", item.getTitle());
            v.put("category", item.getCategory());
            v.put("place", item.getPlace());
            v.put("date_iso", item.getDateIso());
            v.put("latitude", item.getLatitude());
            v.put("longitude", item.getLongitude());
            v.put("reported_by", item.getReportedBy());
            v.put("reporter_email", item.getReporterEmail().toLowerCase(Locale.ROOT));
            v.put("contact", item.getContact());
            v.put("status", Item.STATUS_OPEN);
            db.insertOrThrow("items", null, v);

            db.setTransactionSuccessful();
            return code;
        } finally {
            db.endTransaction();
        }
    }

    public void markReturned(String code) {
        ContentValues v = new ContentValues();
        v.put("status", Item.STATUS_RETURNED);
        getWritableDatabase().update("items", v, "code = ?", new String[]{code});
    }

    private Item readItem(Cursor c) {
        Item item = new Item();
        item.setNumber(c.getInt(c.getColumnIndexOrThrow("id_num")));
        item.setCode(c.getString(c.getColumnIndexOrThrow("code")));
        item.setType(c.getString(c.getColumnIndexOrThrow("type")));
        item.setTitle(c.getString(c.getColumnIndexOrThrow("title")));
        item.setCategory(c.getString(c.getColumnIndexOrThrow("category")));
        item.setPlace(c.getString(c.getColumnIndexOrThrow("place")));
        item.setDateIso(c.getString(c.getColumnIndexOrThrow("date_iso")));
        item.setLatitude(c.getDouble(c.getColumnIndexOrThrow("latitude")));
        item.setLongitude(c.getDouble(c.getColumnIndexOrThrow("longitude")));
        item.setReportedBy(c.getString(c.getColumnIndexOrThrow("reported_by")));
        item.setReporterEmail(c.getString(c.getColumnIndexOrThrow("reporter_email")));
        item.setContact(c.getString(c.getColumnIndexOrThrow("contact")));
        item.setStatus(c.getString(c.getColumnIndexOrThrow("status")));
        return item;
    }
}
