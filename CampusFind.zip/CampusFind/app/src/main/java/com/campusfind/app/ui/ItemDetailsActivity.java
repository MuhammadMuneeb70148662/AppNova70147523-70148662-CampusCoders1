package com.campusfind.app.ui;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.campusfind.app.R;
import com.campusfind.app.auth.SessionManager;
import com.campusfind.app.data.DatabaseHelper;
import com.campusfind.app.model.Item;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import java.util.Locale;

/** Full details of one item, with Open in Maps and Mark as Returned (F5, F10, F12). */
public class ItemDetailsActivity extends AppCompatActivity {

    public static final String EXTRA_CODE = "item_code";

    private DatabaseHelper db;
    private SessionManager session;
    private Item item;

    private LinearLayout rowsContainer;
    private TextView tvTypeTag, tvReturnedTag, tvTitle;
    private View btnMarkReturned;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        session = new SessionManager(this);
        if (!session.isLoggedIn()) {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_item_details);
        db = DatabaseHelper.getInstance(this);

        item = db.getItem(getIntent().getStringExtra(EXTRA_CODE));
        if (item == null) {
            finish();
            return;
        }

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        rowsContainer = findViewById(R.id.rows_container);
        tvTypeTag = findViewById(R.id.tv_type_tag);
        tvReturnedTag = findViewById(R.id.tv_returned_tag);
        tvTitle = findViewById(R.id.tv_title);
        btnMarkReturned = findViewById(R.id.btn_mark_returned);

        findViewById(R.id.btn_open_maps).setOnClickListener(v -> openInMaps());
        btnMarkReturned.setOnClickListener(v -> confirmReturned());

        bind();
    }

    private void bind() {
        tvTypeTag.setText(item.getType().toUpperCase(Locale.ROOT));
        tvTypeTag.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this,
                item.isLost() ? R.color.tag_lost : R.color.tag_found)));

        tvReturnedTag.setVisibility(item.isReturned() ? View.VISIBLE : View.GONE);
        tvReturnedTag.setBackgroundTintList(ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.tag_returned)));

        tvTitle.setText(item.getTitle());

        rowsContainer.removeAllViews();
        addRow(R.string.label_id, item.getCode());
        addRow(R.string.label_type, item.getType());
        addRow(R.string.label_title, item.getTitle());
        addRow(R.string.label_category, item.getCategory());
        addRow(R.string.label_place, item.getPlace());
        addRow(R.string.label_date, item.getDisplayDate());
        addRow(R.string.label_coordinates, String.format(Locale.US, "%.5f, %.5f",
                item.getLatitude(), item.getLongitude()));
        addRow(R.string.label_reported_by, item.getReportedBy());
        addRow(R.string.label_contact, item.getContact());
        addRow(R.string.label_status, item.getStatus());

        // only the person who reported it can mark it as returned (R8)
        boolean isOwner = !item.getReporterEmail().isEmpty()
                && item.getReporterEmail().equalsIgnoreCase(session.getEmail());
        btnMarkReturned.setVisibility(isOwner && !item.isReturned() ? View.VISIBLE : View.GONE);
    }

    private void addRow(int labelRes, String value) {
        View row = LayoutInflater.from(this).inflate(R.layout.row_detail, rowsContainer, false);
        ((TextView) row.findViewById(R.id.tv_label)).setText(labelRes);
        ((TextView) row.findViewById(R.id.tv_value)).setText(value);
        rowsContainer.addView(row);
    }

    private void confirmReturned() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.confirm_returned_title)
                .setMessage(R.string.confirm_returned_msg)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.yes, (dialog, which) -> {
                    db.markReturned(item.getCode());
                    item = db.getItem(item.getCode());
                    bind();
                    Snackbar.make(findViewById(R.id.root), R.string.marked_returned, Snackbar.LENGTH_LONG).show();
                })
                .show();
    }

    private void openInMaps() {
        // geo:0,0?q=lat,lng(label) drops a labelled pin at the saved spot
        String label = Uri.encode(item.getTitle());
        Uri geo = Uri.parse(String.format(Locale.US, "geo:0,0?q=%.5f,%.5f(%s)",
                item.getLatitude(), item.getLongitude(), label));
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, geo));
        } catch (ActivityNotFoundException noMapsApp) {
            // fall back to the browser version of the map
            Uri web = Uri.parse(String.format(Locale.US,
                    "https://www.google.com/maps/search/?api=1&query=%.5f,%.5f",
                    item.getLatitude(), item.getLongitude()));
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, web));
            } catch (ActivityNotFoundException e) {
                Snackbar.make(findViewById(R.id.root), R.string.no_maps_app, Snackbar.LENGTH_LONG).show();
            }
        }
    }
}
