package com.campusfind.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.campusfind.app.R;
import com.campusfind.app.data.DatabaseHelper;
import com.campusfind.app.model.Item;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Home tab: every reported item, newest first, with a Lost/Found filter and search. */
public class HomeFragment extends Fragment {

    private DatabaseHelper db;
    private ItemAdapter adapter;
    private ChipGroup chipGroup;
    private TextInputEditText etSearch;
    private TextView tvEmpty;

    private List<Item> allItems = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = DatabaseHelper.getInstance(requireContext());

        chipGroup = view.findViewById(R.id.chip_group);
        etSearch = view.findViewById(R.id.et_search);
        tvEmpty = view.findViewById(R.id.tv_empty);

        adapter = new ItemAdapter(item -> {
            Intent intent = new Intent(requireContext(), ItemDetailsActivity.class);
            intent.putExtra(ItemDetailsActivity.EXTRA_CODE, item.getCode());
            startActivity(intent);
        });
        RecyclerView list = view.findViewById(R.id.rv_items);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        list.setAdapter(adapter);

        chipGroup.setOnCheckedStateChangeListener((group, ids) -> applyFilter());
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { applyFilter(); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        // reload so new reports and status changes show up straight away
        allItems = db.getAllItems();
        applyFilter();
    }

    private void applyFilter() {
        int checked = chipGroup.getCheckedChipId();
        String query = etSearch.getText() == null ? ""
                : etSearch.getText().toString().trim().toLowerCase(Locale.ROOT);

        List<Item> shown = new ArrayList<>();
        for (Item item : allItems) {
            if (checked == R.id.chip_lost && !item.isLost()) continue;
            if (checked == R.id.chip_found && item.isLost()) continue;

            if (!query.isEmpty()) {
                String haystack = (item.getTitle() + " " + item.getPlace() + " "
                        + item.getCategory() + " " + item.getCode()).toLowerCase(Locale.ROOT);
                if (!haystack.contains(query)) continue;
            }
            shown.add(item);
        }

        adapter.setItems(shown);
        tvEmpty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
