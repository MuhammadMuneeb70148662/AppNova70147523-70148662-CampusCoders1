package com.campusfind.app.auth;

import android.content.Context;
import android.content.SharedPreferences;

import com.campusfind.app.model.User;

/** Remembers who is logged in so the session survives an app restart (R2 / F9). */
public class SessionManager {

    private static final String PREFS = "campusfind_session";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_NAME = "name";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void login(User user) {
        prefs.edit()
                .putString(KEY_EMAIL, user.getEmail())
                .putString(KEY_NAME, user.getFullName())
                .apply();
    }

    public void logout() {
        prefs.edit().clear().apply();
    }

    public boolean isLoggedIn() {
        return prefs.getString(KEY_EMAIL, null) != null;
    }

    public String getEmail() {
        return prefs.getString(KEY_EMAIL, "");
    }

    public String getName() {
        return prefs.getString(KEY_NAME, "");
    }
}
