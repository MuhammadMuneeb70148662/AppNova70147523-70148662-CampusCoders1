package com.campusfind.app.util;

import android.util.Patterns;

/** Input rules from the business rules R1 and R3. */
public final class Validator {

    private Validator() { }

    /** Letters and spaces only, at least 3 characters. */
    public static boolean isValidName(String name) {
        String t = name.trim();
        return t.length() >= 3 && t.matches("[\\p{L} ]+");
    }

    public static boolean isValidEmail(String email) {
        return !email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    /** At least 6 characters and at least one digit. */
    public static boolean isValidPassword(String password) {
        return password.length() >= 6 && password.matches(".*\\d.*");
    }

    public static boolean isValidTitle(String title) {
        return title.trim().length() >= 3;
    }

    /** 11 digits starting with 03, e.g. 03001234567. */
    public static boolean isValidContact(String contact) {
        return contact.matches("03\\d{9}");
    }
}
