package com.campusfind.app.model;

/** A registered CampusFind account. The password itself is never kept, only salt + hash. */
public class User {
    private final String fullName;
    private final String email;
    private final String salt;
    private final String passwordHash;

    public User(String fullName, String email, String salt, String passwordHash) {
        this.fullName = fullName;
        this.email = email;
        this.salt = salt;
        this.passwordHash = passwordHash;
    }

    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getSalt() { return salt; }
    public String getPasswordHash() { return passwordHash; }
}
