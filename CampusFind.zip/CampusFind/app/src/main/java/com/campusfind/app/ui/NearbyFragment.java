package com.campusfind.app.ui;

import android.Manifest;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.campusfind.app.R;
import com.campusfind.app.data.DatabaseHelper;
import com.campusfind.app.location.LocationHelper;
import com.campusfind.app.model.Item;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Nearby tab: all items sorted by distance from the user's current position (R7). */
public class NearbyFragment extends Fragment {

    private TextView tvStatus;
    private ItemAdapter adapter;
    private DatabaseHelper db;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    loadNearby();
                } else {
                    showProblem(getString(R.string.err_location_permission));
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_nearby, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = DatabaseHelper.getInstance(requireContext());
        tvStatus = view.findViewById(R.id.tv_status);

        adapter = new ItemAdapter(item -> {
            Intent intent = new Intent(requireContext(), ItemDetailsActivity.class);
            intent.putExtra(ItemDetailsActivity.EXTRA_CODE, item.getCode());
            startActivity(intent);
        });
        RecyclerView list = view.findViewById(R.id.rv_nearby);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        list.setAdapter(adapter);

        view.findViewById(R.id.btn_refresh).setOnClickListener(v -> startLoading());
        startLoading();
    }

    private void startLoading() {
        if (LocationHelper.hasPermission(requireContext())) {
            loadNearby();
        } else {
            permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    private void loadNearby() {
        tvStatus.setText(R.string.nearby_getting);
        LocationHelper.fetch(requireContext(), new LocationHelper.Callback() {
            @Override
            public void onLocation(Location here) {
                if (!isAdded()) return;

                List<Item> items = db.getAllItems();
                float[] result = new float[1];
                for (Item item : items) {
                    Location.distanceBetween(here.getLatitude(), here.getLongitude(),
                            item.getLatitude(), item.getLongitude(), result);
                    item.setDistanceMeters(result[0]);
                }
                Collections.sort(items, (a, b) -> Float.compare(a.getDistanceMeters(), b.getDistanceMeters()));

                tvStatus.setText(getString(R.string.nearby_your_location,
                        String.format(Locale.US, "%.5f", here.getLatitude()),
                        String.format(Locale.US, "%.5f", here.getLongitude())));
                adapter.setItems(items);
            }

            @Override
            public void onFailure(String message) {
                if (isAdded()) showProblem(message);
            }
        });
    }

    private void showProblem(String message) {
        tvStatus.setText(message);
        adapter.setItems(Collections.emptyList());
    }
}
