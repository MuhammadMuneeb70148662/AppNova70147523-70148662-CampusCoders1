package com.campusfind.app.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.campusfind.app.R;
import com.campusfind.app.auth.PasswordHasher;
import com.campusfind.app.auth.SessionManager;
import com.campusfind.app.data.DatabaseHelper;
import com.campusfind.app.model.User;
import com.campusfind.app.util.Validator;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Locale;

/** Sign Up screen, rules R1. */
public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout tilName, tilEmail, tilPassword, tilConfirm;
    private TextInputEditText etName, etEmail, etPassword, etConfirm;

    private DatabaseHelper db;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = DatabaseHelper.getInstance(this);
        session = new SessionManager(this);

        tilName = findViewById(R.id.til_name);
        tilEmail = findViewById(R.id.til_email);
        tilPassword = findViewById(R.id.til_password);
        tilConfirm = findViewById(R.id.til_confirm);
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etConfirm = findViewById(R.id.et_confirm);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        findViewById(R.id.btn_register).setOnClickListener(v -> attemptRegister());
        findViewById(R.id.btn_go_login).setOnClickListener(v -> finish());
    }

    private void attemptRegister() {
        tilName.setError(null);
        tilEmail.setError(null);
        tilPassword.setError(null);
        tilConfirm.setError(null);

        String name = read(etName);
        String email = read(etEmail).toLowerCase(Locale.ROOT);
        String password = etPassword.getText() == null ? "" : etPassword.getText().toString();
        String confirm = etConfirm.getText() == null ? "" : etConfirm.getText().toString();

        boolean valid = true;
        if (!Validator.isValidName(name)) {
            tilName.setError(getString(R.string.err_name));
            valid = false;
        }
        if (!Validator.isValidEmail(email)) {
            tilEmail.setError(getString(R.string.err_email));
            valid = false;
        }
        if (!Validator.isValidPassword(password)) {
            tilPassword.setError(getString(R.string.err_password));
            valid = false;
        }
        if (!password.equals(confirm)) {
            tilConfirm.setError(getString(R.string.err_confirm));
            valid = false;
        }
        if (!valid) {
            return;
        }

        String salt = PasswordHasher.newSalt();
        User user = new User(name, email, salt, PasswordHasher.hash(password, salt));

        if (!db.addUser(user)) {
            tilEmail.setError(getString(R.string.err_email_exists));
            Snackbar.make(findViewById(R.id.root), R.string.err_email_exists, Snackbar.LENGTH_LONG).show();
            return;
        }

        // registered successfully, so sign the person straight in
        session.login(user);
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private String read(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
