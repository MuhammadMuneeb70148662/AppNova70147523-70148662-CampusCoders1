package com.campusfind.app.util;

import java.util.Locale;

/** Whole metres below 1,000 m, otherwise kilometres with one decimal (R7). */
public final class DistanceFormatter {

    private DistanceFormatter() { }

    public static String format(float meters) {
        int whole = Math.round(meters);
        if (whole < 1000) {
            return String.format(Locale.US, "%d m", whole);
        }
        return String.format(Locale.US, "%.1f km", meters / 1000f);
    }
}
