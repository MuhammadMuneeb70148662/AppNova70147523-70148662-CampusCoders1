package com.campusfind.app.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.campusfind.app.R;
import com.campusfind.app.auth.SessionManager;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

/** Hosts the four tabs: Home, Nearby, Report and Profile. */
public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // no screen is reachable without a login (R2)
        if (!new SessionManager(this).isLoggedIn()) {
            goToLogin();
            return;
        }

        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        bottomNav = findViewById(R.id.bottom_nav);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                show(new HomeFragment(), R.string.tab_home);
            } else if (id == R.id.nav_nearby) {
                show(new NearbyFragment(), R.string.tab_nearby);
            } else if (id == R.id.nav_report) {
                show(new ReportFragment(), R.string.tab_report);
            } else {
                show(new ProfileFragment(), R.string.tab_profile);
            }
            return true;
        });

        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.nav_home);
        } else {
            toolbar.setTitle(titleFor(bottomNav.getSelectedItemId()));
        }

        // Back from any other tab returns to Home first, then leaves the app
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (bottomNav.getSelectedItemId() != R.id.nav_home) {
                    bottomNav.setSelectedItemId(R.id.nav_home);
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
    }

    private void show(Fragment fragment, int titleRes) {
        toolbar.setTitle(titleRes);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    private int titleFor(int menuId) {
        if (menuId == R.id.nav_nearby) return R.string.tab_nearby;
        if (menuId == R.id.nav_report) return R.string.tab_report;
        if (menuId == R.id.nav_profile) return R.string.tab_profile;
        return R.string.tab_home;
    }

    /** Used by the Report tab after saving. */
    public void openHome() {
        bottomNav.setSelectedItemId(R.id.nav_home);
    }

    public void showMessage(String message) {
        Snackbar.make(findViewById(R.id.root), message, Snackbar.LENGTH_LONG)
                .setAnchorView(bottomNav)
                .show();
    }

    /** Clears the whole back stack so Back cannot return to the app screens after logout. */
    public void goToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
