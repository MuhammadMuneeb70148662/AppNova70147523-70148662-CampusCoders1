package com.campusfind.app.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.campusfind.app.R;
import com.campusfind.app.auth.PasswordHasher;
import com.campusfind.app.auth.SessionManager;
import com.campusfind.app.data.DatabaseHelper;
import com.campusfind.app.model.User;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/** Launcher screen. Skips straight to Home when a session already exists. */
public class LoginActivity extends AppCompatActivity {

    private TextInputLayout tilEmail;
    private TextInputLayout tilPassword;
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;

    private SessionManager session;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        session = new SessionManager(this);
        if (session.isLoggedIn()) {
            openHome();
            return;
        }

        setContentView(R.layout.activity_login);
        db = DatabaseHelper.getInstance(this);

        tilEmail = findViewById(R.id.til_email);
        tilPassword = findViewById(R.id.til_password);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);

        findViewById(R.id.btn_login).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.btn_go_register).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void attemptLogin() {
        tilEmail.setError(null);
        tilPassword.setError(null);

        String email = textOf(etEmail);
        String password = etPassword.getText() == null ? "" : etPassword.getText().toString();

        boolean complete = true;
        if (email.isEmpty()) {
            tilEmail.setError(getString(R.string.err_enter_email));
            complete = false;
        }
        if (password.isEmpty()) {
            tilPassword.setError(getString(R.string.err_enter_password));
            complete = false;
        }
        if (!complete) {
            return;
        }

        User user = db.findUser(email);
        boolean ok = user != null
                && PasswordHasher.verify(password, user.getSalt(), user.getPasswordHash());

        if (!ok) {
            tilPassword.setError(getString(R.string.err_invalid_login));
            Snackbar.make(findViewById(R.id.root), R.string.err_invalid_login, Snackbar.LENGTH_LONG).show();
            return;
        }

        session.login(user);
        openHome();
    }

    private void openHome() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private String textOf(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
