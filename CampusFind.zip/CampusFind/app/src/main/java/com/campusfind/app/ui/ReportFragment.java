package com.campusfind.app.ui;

import android.Manifest;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.campusfind.app.R;
import com.campusfind.app.auth.SessionManager;
import com.campusfind.app.data.DatabaseHelper;
import com.campusfind.app.location.LocationHelper;
import com.campusfind.app.model.Item;
import com.campusfind.app.util.Validator;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.time.LocalDate;
import java.util.Locale;

/** Report tab: validated form, GPS tagging and saving (R3, R4, R5). */
public class ReportFragment extends Fragment {

    private MaterialButtonToggleGroup toggleType;
    private TextView tvTypeError, tvCoords, tvLocationError;
    private TextInputLayout tilTitle, tilCategory, tilPlace, tilContact;
    private TextInputEditText etTitle, etPlace, etContact;
    private MaterialAutoCompleteTextView actvCategory;
    private MaterialButton btnLocation;

    private Double latitude;
    private Double longitude;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    fetchLocation();
                } else {
                    showLocationError(getString(R.string.err_location_permission));
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_report, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        toggleType = view.findViewById(R.id.toggle_type);
        tvTypeError = view.findViewById(R.id.tv_type_error);
        tvCoords = view.findViewById(R.id.tv_coords);
        tvLocationError = view.findViewById(R.id.tv_location_error);
        tilTitle = view.findViewById(R.id.til_title);
        tilCategory = view.findViewById(R.id.til_category);
        tilPlace = view.findViewById(R.id.til_place);
        tilContact = view.findViewById(R.id.til_contact);
        etTitle = view.findViewById(R.id.et_title);
        etPlace = view.findViewById(R.id.et_place);
        etContact = view.findViewById(R.id.et_contact);
        actvCategory = view.findViewById(R.id.actv_category);
        btnLocation = view.findViewById(R.id.btn_location);

        actvCategory.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                getResources().getStringArray(R.array.categories)));

        toggleType.addOnButtonCheckedListener((group, checkedId, isChecked) ->
                tvTypeError.setVisibility(View.GONE));

        btnLocation.setOnClickListener(v -> {
            if (LocationHelper.hasPermission(requireContext())) {
                fetchLocation();
            } else {
                permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
            }
        });
        view.findViewById(R.id.btn_submit).setOnClickListener(v -> submit());
    }

    private void fetchLocation() {
        tvLocationError.setVisibility(View.GONE);
        btnLocation.setEnabled(false);
        btnLocation.setText(R.string.getting_location);

        LocationHelper.fetch(requireContext(), new LocationHelper.Callback() {
            @Override
            public void onLocation(Location location) {
                if (!isAdded()) return;
                resetLocationButton();
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                tvCoords.setText(String.format(Locale.US, "Latitude: %.5f\nLongitude: %.5f",
                        latitude, longitude));
            }

            @Override
            public void onFailure(String message) {
                if (!isAdded()) return;
                resetLocationButton();
                showLocationError(message);
            }
        });
    }

    private void resetLocationButton() {
        btnLocation.setEnabled(true);
        btnLocation.setText(R.string.use_my_location);
    }

    private void showLocationError(String message) {
        tvLocationError.setText(message);
        tvLocationError.setVisibility(View.VISIBLE);
    }

    private void submit() {
        tilTitle.setError(null);
        tilCategory.setError(null);
        tilPlace.setError(null);
        tilContact.setError(null);
        tvTypeError.setVisibility(View.GONE);
        tvLocationError.setVisibility(View.GONE);

        String type = null;
        int checked = toggleType.getCheckedButtonId();
        if (checked == R.id.btn_type_lost) type = Item.TYPE_LOST;
        if (checked == R.id.btn_type_found) type = Item.TYPE_FOUND;

        String title = read(etTitle);
        String category = actvCategory.getText() == null ? "" : actvCategory.getText().toString().trim();
        String place = read(etPlace);
        String contact = read(etContact);

        boolean valid = true;
        if (type == null) {
            tvTypeError.setVisibility(View.VISIBLE);
            valid = false;
        }
        if (!Validator.isValidTitle(title)) {
            tilTitle.setError(getString(R.string.err_item_title));
            valid = false;
        }
        if (category.isEmpty()) {
            tilCategory.setError(getString(R.string.err_category));
            valid = false;
        }
        if (place.isEmpty()) {
            tilPlace.setError(getString(R.string.err_place));
            valid = false;
        }
        if (!Validator.isValidContact(contact)) {
            tilContact.setError(getString(R.string.err_contact));
            valid = false;
        }
        if (latitude == null || longitude == null) {
            showLocationError(getString(LocationHelper.hasPermission(requireContext())
                    ? R.string.err_location_missing : R.string.err_location_permission));
            valid = false;
        }
        if (!valid) {
            return;
        }

        SessionManager session = new SessionManager(requireContext());
        Item item = new Item();
        item.setType(type);
        item.setTitle(title);
        item.setCategory(category);
        item.setPlace(place);
        item.setContact(contact);
        item.setDateIso(LocalDate.now().toString());
        item.setLatitude(latitude);
        item.setLongitude(longitude);
        item.setReportedBy(session.getName());
        item.setReporterEmail(session.getEmail());

        String code;
        try {
            code = DatabaseHelper.getInstance(requireContext()).insertItem(item);
        } catch (Exception e) {
            Snackbar.make(requireView(), R.string.err_generic_save, Snackbar.LENGTH_LONG).show();
            return;
        }

        MainActivity main = (MainActivity) requireActivity();
        main.showMessage(getString(R.string.saved_item, code));
        main.openHome();
    }

    private String read(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
