package com.campusfind.app.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.campusfind.app.R;
import com.campusfind.app.auth.SessionManager;
import com.google.android.material.snackbar.Snackbar;

import java.util.Locale;

/** Profile tab: account details, team, repository link and Logout (F3, F9). */
public class ProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SessionManager session = new SessionManager(requireContext());

        String name = session.getName();
        ((TextView) view.findViewById(R.id.tv_name)).setText(name);
        ((TextView) view.findViewById(R.id.tv_email)).setText(session.getEmail());
        ((TextView) view.findViewById(R.id.tv_avatar)).setText(
                name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT));

        ((TextView) view.findViewById(R.id.tv_team_name)).setText(getString(R.string.team_name));
        ((TextView) view.findViewById(R.id.tv_team_members)).setText(getString(R.string.team_members));

        String url = getString(R.string.github_url);
        ((TextView) view.findViewById(R.id.tv_github_url)).setText(url);
        view.findViewById(R.id.btn_github).setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e) {
                Snackbar.make(view, R.string.cannot_open_link, Snackbar.LENGTH_SHORT).show();
            }
        });

        view.findViewById(R.id.btn_logout).setOnClickListener(v -> {
            session.logout();
            ((MainActivity) requireActivity()).goToLogin();
        });
    }
}
