package com.campusfind.app.location;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.core.content.ContextCompat;

import com.campusfind.app.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;

/** All GPS access lives here so the screens stay simple (R4). */
public final class LocationHelper {

    public interface Callback {
        void onLocation(Location location);
        void onFailure(String message);
    }

    private LocationHelper() { }

    public static boolean hasPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission") // checked by hasPermission() below
    public static void fetch(Context context, Callback callback) {
        if (!hasPermission(context)) {
            callback.onFailure(context.getString(R.string.err_location_permission));
            return;
        }
        final String failMessage = context.getString(R.string.err_location_failed);
        final FusedLocationProviderClient client =
                LocationServices.getFusedLocationProviderClient(context);

        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, new CancellationTokenSource().getToken())
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        callback.onLocation(location);
                    } else {
                        // no fresh fix, so fall back to the last known one
                        client.getLastLocation()
                                .addOnSuccessListener(last -> {
                                    if (last != null) {
                                        callback.onLocation(last);
                                    } else {
                                        callback.onFailure(failMessage);
                                    }
                                })
                                .addOnFailureListener(e -> callback.onFailure(failMessage));
                    }
                })
                .addOnFailureListener(e -> callback.onFailure(failMessage));
    }
}
