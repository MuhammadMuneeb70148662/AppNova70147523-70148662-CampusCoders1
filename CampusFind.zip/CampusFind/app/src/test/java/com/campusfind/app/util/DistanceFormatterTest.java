package com.campusfind.app.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class DistanceFormatterTest {

    @Test
    public void belowOneKilometre_usesWholeMetres() {
        assertEquals("0 m", DistanceFormatter.format(0f));
        assertEquals("245 m", DistanceFormatter.format(245.4f));
        assertEquals("999 m", DistanceFormatter.format(999.2f));
    }

    @Test
    public void oneKilometreAndAbove_usesOneDecimal() {
        assertEquals("1.0 km", DistanceFormatter.format(1000f));
        assertEquals("1.2 km", DistanceFormatter.format(1234f));
        assertEquals("12.5 km", DistanceFormatter.format(12500f));
    }

    @Test
    public void roundingUpToOneThousand_switchesToKilometres() {
        assertEquals("1.0 km", DistanceFormatter.format(999.7f));
    }
}
