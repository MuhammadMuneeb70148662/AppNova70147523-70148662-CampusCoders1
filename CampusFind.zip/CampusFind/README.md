# CampusFind

A campus lost-and-found app for Android. Students register, log in, report lost or
found items with their GPS location, browse everything that has been reported, see
which items are nearest to them, and mark their own reports as returned.

Built with Java, Material 3 and a local SQLite database.

## App

| | |
|---|---|
| App name | **CampusFind** |
| Icon | Custom vector launcher icon (magnifier with a map pin), `res/drawable/ic_launcher_foreground.xml` |
| Team name | _your team name_ |
| Entry ID | _your entry id_ |
| Members | _Name – SAP ID_ (edit the same details in `res/values/strings.xml` so they show on the Profile tab) |

## Stack

- Language: Java 17
- IDE: Android Studio (Koala or newer), Android Gradle Plugin 8.5.2, Gradle 8.7
- UI: Material Components for Android 1.12 (Material 3 theme), RecyclerView, BottomNavigationView
- Database: local SQLite through `SQLiteOpenHelper` (no cloud setup needed)
- Auth: accounts stored in SQLite, passwords hashed with salted PBKDF2-HMAC-SHA256
- Location: Google Play Services `FusedLocationProviderClient`
- minSdk 26, targetSdk 34

## Project structure

```
com.campusfind.app
 ├─ auth      PasswordHasher, SessionManager
 ├─ data      DatabaseHelper (users + items, starter data)
 ├─ location  LocationHelper (permission check + GPS fix)
 ├─ model     User, Item
 ├─ ui        Login / Register / Main / ItemDetails activities,
 │            Home / Nearby / Report / Profile fragments, ItemAdapter
 └─ util      Validator, DistanceFormatter
```

## Features completed

| | Feature |
|---|---|
| F1 | Own launcher icon, app name "CampusFind" |
| F2 | Separate Sign In and Sign Up screens with links to each other; opens on Login when nobody is signed in |
| F3 | Bottom navigation (Home, Nearby, Report, Profile); Profile shows name, email, team, GitHub link, Logout |
| F4 | Home list (RecyclerView) with the 6 starter items, newest first |
| F5 | Item details screen with every field |
| F6 | Report form with per-field validation |
| F7 | "Use my current location" with run-time permission, 5 decimal places |
| F8 | Items saved to SQLite with the next ID (CF-07, CF-08 …), today's date, status Open |
| F9 | Session survives a restart; Logout clears the back stack |
| F10 | Open in Maps with a pin on the saved location |
| F11 | Nearby tab sorted by distance (m below 1,000, otherwise km with one decimal) |
| F12 | Lost/Found filter chips plus search on Home; Mark as Returned for the reporter only |

## Run it

1. Open Android Studio, choose **Open** and select the `CampusFind` folder.
2. Let Gradle sync finish (it downloads the Gradle wrapper and libraries, so it needs internet the first time).
3. Create or pick an emulator with **Google Play / Google APIs** (API 26 or newer), or plug in a phone.
4. Press **Run**.
5. Register an account and you land on Home.

### Testing location on the emulator

Open **Extended controls (…) → Location**, search or enter `31.38955, 74.24070`
(Main Library) and press **Set location**. Then use the Report and Nearby tabs.
The emulator's default position is in California, so distances will show in thousands of km until you change it.

## Screenshots

Add 3–5 screenshots to a `screenshots/` folder and list them here.

## Tests

`./gradlew test` runs the unit tests for `DistanceFormatter`.
